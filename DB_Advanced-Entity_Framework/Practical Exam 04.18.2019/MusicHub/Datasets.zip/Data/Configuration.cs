﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-3D63KAF\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}

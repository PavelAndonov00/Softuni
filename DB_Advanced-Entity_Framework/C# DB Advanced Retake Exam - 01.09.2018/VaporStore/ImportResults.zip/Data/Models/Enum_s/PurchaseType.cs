﻿namespace VaporStore.Data.Models.Enum_s
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public enum PurchaseType
    {
        Retail,
        Digital
    }
}

﻿namespace IRunes.Data
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-3D63KAF\SQLEXPRESS;Database=IRunesDB;Trusted_Connection=True;Integrated Security=True;";
    }
}

﻿namespace IRunes.App.ViewModels.Tracks
{
    public class CreateInputModel
    {
        public string AlbumId { get; set; }

        public string Name { get; set; }

        public string Link { get; set; }

        public decimal Price { get; set; }
    }
}

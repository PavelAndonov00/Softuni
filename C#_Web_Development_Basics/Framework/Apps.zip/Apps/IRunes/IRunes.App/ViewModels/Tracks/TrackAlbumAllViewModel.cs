﻿namespace IRunes.App.ViewModels.Tracks
{
    public class TrackAlbumAllViewModel
    {
        public string Id { get; set; }

        public string Name { get; set; }
    }
}

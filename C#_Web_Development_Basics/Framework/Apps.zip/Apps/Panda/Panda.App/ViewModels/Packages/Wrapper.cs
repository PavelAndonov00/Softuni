﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Panda.App.ViewModels.Packages
{
    public class Wrapper
    {
        public IEnumerable<PackagesPendingModel> Packages { get; set; }
    }
}

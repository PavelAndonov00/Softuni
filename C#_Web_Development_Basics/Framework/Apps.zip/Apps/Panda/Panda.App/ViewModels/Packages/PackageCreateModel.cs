﻿using SIS.MvcFramework.Attributes.Validation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Panda.App.ViewModels.Packages
{
    public class PackageCreateModel
    {
        [RequiredSis]
        [StringLengthSis(5, 20, "Invalid description!")]
        public string Description { get; set; }

        public decimal Weight { get; set; }

        public string ShippingAddress { get; set; }

        public string RecipientName { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Panda.App.ViewModels.Packages
{
    public class PackageDeliverModel
    {
        public string id { get; set; }
    }
}

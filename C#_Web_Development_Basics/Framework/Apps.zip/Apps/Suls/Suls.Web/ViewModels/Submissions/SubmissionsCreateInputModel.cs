﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Suls.Web.ViewModels.Submissions
{
    public class SubmissionsCreateInputModel
    {
        public string Id { get; set; }
    }
}

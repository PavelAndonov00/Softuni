﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Suls.Web.ViewModels.Submissions
{
    public class SubmissionsDeleteModel
    {
        public string Id { get; set; }
    }
}

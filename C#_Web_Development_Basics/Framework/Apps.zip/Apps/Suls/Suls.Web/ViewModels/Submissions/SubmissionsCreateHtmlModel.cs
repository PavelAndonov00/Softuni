﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Suls.Web.ViewModels.Submissions
{
    public class SubmissionsCreateHtmlModel
    {
        public string Name { get; set; }

        public string ProblemId { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Suls.Web.ViewModels.Problems
{
    public class ProblemsDetailsModel
    {
        public string Id { get; set; }
    }
}

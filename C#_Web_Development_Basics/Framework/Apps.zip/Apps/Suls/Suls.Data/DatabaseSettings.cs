﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Suls.Data
{
    public static class DatabaseSettings
    {
        public const string connectionString = @"Server=DESKTOP-3D63KAF\SQLEXPRESS;Database=SulsDB-Pavel00;Trusted_Connection=true;";
    }
}

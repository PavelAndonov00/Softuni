﻿using System;

namespace Musaca.Data
{
    public static class DatabaseConfiguration
    {
        public const string connectionString = @"Server=DESKTOP-3D63KAF\SQLEXPRESS;Database=MusacaDB;Trusted_Connection=True;";
    }
}

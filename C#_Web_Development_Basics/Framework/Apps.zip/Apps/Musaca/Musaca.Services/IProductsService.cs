﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Musaca.Services
{
    public interface IProductsService
    {
    }
}

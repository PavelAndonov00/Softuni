﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Musaca.Services
{
    public class ProductsService : IProductsService
    {
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Musaca.App.ViewModels.Users
{
    public class UsersLoginFormDataModel
    {
        public string username { get; set; }

        public string password { get; set; }
    }
}

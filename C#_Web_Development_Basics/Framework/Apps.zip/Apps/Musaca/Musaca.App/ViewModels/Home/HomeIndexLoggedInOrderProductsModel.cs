﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Musaca.App.ViewModels.Home
{
    public class HomeIndexLoggedInOrderProductsModel
    {
        public string ProductName { get; set; }

        public decimal ProductPrice { get; set; }
    }
}

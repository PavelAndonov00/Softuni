﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Panda.Models.Enums
{
    public enum PackageStatus
    {
        Pending = 1,
        Delivered = 2
    }
}

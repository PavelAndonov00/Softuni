﻿namespace Panda.Data
{
    public static class DatabaseSettings
    {
        public const string connectionString = @"Server=DESKTOP-3D63KAF\SQLEXPRESS;Database=PandaDB;Trusted_Connection=true;";
    }
}
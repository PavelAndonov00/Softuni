﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankAccount
{
    class BankAccount
    {
        public int id { get; set; }
        public decimal balance { get; set; }

    }
}

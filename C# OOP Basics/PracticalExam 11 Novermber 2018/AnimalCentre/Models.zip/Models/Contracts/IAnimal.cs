﻿namespace AnimalCentre.Models.Contracts
{
    public interface IAnimal
    {
        string ToString();
    }
}
